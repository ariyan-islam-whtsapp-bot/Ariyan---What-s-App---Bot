# ES-Lint

General Typescript ESLint Rules I use.

To use in your project:
```
yarn add git+https://github.com/adiwajshing/eslint
```

Then create an `.eslintrc.json` like (can also be a yaml or js):
``` json
{
	"extends": "@adiwajshing"
}
```
